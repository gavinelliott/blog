<?php
require_once(dirname(__FILE__) . '/lib/common.php');
$this->AddService(new FacebookDataSource('facebook'));
?>