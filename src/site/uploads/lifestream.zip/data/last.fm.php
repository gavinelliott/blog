<?php
require_once(dirname(__FILE__) . '/lib/common.php');
$this->AddService(new RSSDataSource('lastfm', 'http://ws.audioscrobbler.com/1.0/user/elliottback/recenttracks.rss', 60*60*5));
?>