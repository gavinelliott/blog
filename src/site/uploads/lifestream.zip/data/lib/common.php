<?php
	class LifestreamDataSource {
		var $name;
		var $uniques = array();
		
		var $style_bg;
		var $style_link;
		var $style_hover;
		
		function LifestreamDataSource(){
			die("This is an abstract class; you cannot instantiate it!");
		}
		
		function cacheItem($service, $time, $title, $link = '', $checkUniques = false){
			$uniquekey = md5($service . "|" . $title . '|' . $link);
			$uniquesfile = dirname(dirname(__FILE__)). '/cache/uniques';
			$cachefile = dirname(dirname(__FILE__)) . '/cache/' . $time . '.' . $service;
		
			if($checkUniques){
				if(count($this->uniques) == 0){
					$lines = preg_split("`[\r\n]+`si", @file_get_contents($uniquesfile), -1, PREG_SPLIT_NO_EMPTY);
					
					foreach($lines as $line){
						$this->uniques [$line] = true;
					}
				}
				
				if(isset($this->uniques[$uniquekey])) {
					return;
				} else {
					$this->uniques [$uniquekey] = true;
					$fp = fopen($uniquesfile, 'a');
					fwrite($fp, $uniquekey . "\n");
					fclose($fp);
				}
			}
			
			if(!file_exists($cachefile)){
				$fp = fopen($cachefile, 'w');
				fwrite($fp, serialize(array($title, $link)));
				fclose($fp);
			}
		}
		
		function Refresh(){}
		
		function Items(){
			$dirfile = dirname(dirname(__FILE__)) . '/cache/';
			$dir_handle = @opendir($dirfile);
			$items = array();
			
			while($file = readdir($dir_handle)){
				if($file == '.' || $file == '..' || !preg_match('`\.' . $this->name . '$`', $file))
					continue;
				else {
					$time = str_replace('.' . $this->name, '', $file);
					$content = unserialize(file_get_contents($dirfile . $file));
					$items [$time] = array($content[0], $content[1]);
				}
			}
			
			closedir($dir_handle);
			return $items;
		}
		
		function BG () {
			return $this->style_bg;
		}
		
		function A () {
			return $this->style_link;
		}
		
		function HOVER () {
			return $this->style_hover;
		}
	}
	
	class RSSDataSource extends LifestreamDataSource {
		var $feed;
		var $dateoffset;
		var $checkUniques;
		
		function RSSDataSource($name, $feed, $dateoffset = 0, $checkUniques = false){
			$this->name = $name;
			$this->feed = $feed;
			$this->dateoffset = $dateoffset;
			$this->checkUniques = checkUniques;
		}
		
		function Refresh(){
			$rss = @fetch_rss($this->feed);
			
			if(is_array($rss->items)){
				$now = time();
				$iter = 0;
				
				foreach ($rss->items as $item ) {
					if(empty($item['pubdate'])){
						$date =$now + $iter++;
					} else {
						$date = strtotime(substr($item['pubdate'], 0, 25 )) - $this->dateoffset;
					}
					
					$this->cacheItem($this->name, $date, $item['title'], $item['link'], $this->checkUniques);
				}
			}
		}
	}
	
	class WordpressDataSource extends LifestreamDataSource {
		function WordpressDataSource($name){
			$this->name = $name;
		}
		
		function Refresh(){
			global $wpdb;
			
			$res = $wpdb->get_results("SELECT ID, post_date, post_title FROM " . $wpdb-> posts . " WHERE post_status='publish' AND post_password=''", ARRAY_A);
			if($res === FALSE)
				$wpdb->print_error();
			
			foreach($res as $row){
				$date = strtotime($row['post_date']);
				$title = wp_specialchars($row['post_title'], 1);
				$link = get_permalink($row['ID']);
				$this->cacheItem($this->name, $date, $title, $link);
			}
		}
	}
	
	class FlickrDataSource extends LifestreamDataSource {
		var $apikey = 'your+api+key';
		var $user = 'your+user';
		var $max = 500;
		
		function FlickrDataSource($name){
			$this->name = $name;
			require_once(dirname(__FILE__) . '/phpFlickr.php');
		}
		
		function Refresh(){
			// Create new phpFlickr object
			$f = new phpFlickr($this->apikey);
			$f->enableCache("fs", dirname(__FILE__) . '/flickrcache/');
			
			$person = $f->people_findByUsername($this->user);
			$photos_url = $f->urls_getUserPhotos($person['id']);
			$photos = $f->people_getPublicPhotos($person['id'], NULL, $this->max);
			    
			// Loop through the photos and output the html
			foreach ($photos['photo'] as $photo) {
				$info = $f->photos_getInfo($photo['id']);
			    $link = $photos_url . $photo['id'];
			    $title = "<img style='float:right; height:2em;' alt='$photo[title]' src='" . $f->buildPhotoURL($photo, "Square") . "' /> " 
			    		. $photo['title']
			    		. "<div style='clear:right'></div>";
			    $date = $info['dateuploaded'];
			    $this->cacheItem($this->name, $date, $title, $link);
			}
		}
	}
	
	class FacebookDataSource extends LifestreamDataSource {
		var $config = array();
		
		function FacebookDataSource($name){
			require_once(dirname(__FILE__) . '/facebookapi_php5_restlib.php');
			
			$this->name = $name;
			$this->config['api_server_base_url'] = 'http://api.facebook.com';
			$this->config['login_server_base_url'] = 'http://api.facebook.com';
			$this->config['rest_server_addr'] = $this->config['api_server_base_url']."/restserver.php";
			$this->config['api_key'] = "your+key+here";
			$this->config['secret'] = "your+secret+here";
			$this->config['email'] = 'your+email+here';
			$this->config['pass'] = 'pass+here';
			$this->config['login_url'] = $this->config['login_server_base_url'].'/login.php?next='.urlencode('wp-content/themes/manji/data/sample_client.php').'&api_key='.$this->config['api_key'];
			$this->config['debug'] = 0; // TURN this on for XML input spew
		}
		
		function get_content($url){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			$data = curl_exec($ch);
			curl_close($ch);
			return $data;
		}
		
		function post_content($url, $data){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, 1 );
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) . '/cookie.txt');
			curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) . '/cookie.txt');
			curl_setopt($ch, CURLOPT_HEADER, 1);
			$postResult = curl_exec($ch);
			
			if (curl_errno($ch)) {
			    print curl_error($ch);
			}
		   
			curl_close($ch);
			return $postResult;
		}
		
		function get_auth_token(){
			$loginpage = $this->get_content($this->config['login_url']);
			
			$form = array();
			$form['email'] = $this->config['email'];
			$form['pass'] = $this->config['pass'];
			preg_match('`<input[^>]*id\s*=\s*"challenge"[^>]*value\s*=\s*[\'"]([^"]+)[\'"][^>]*>`si', $loginpage, $matches);
			$form['challenge'] = $matches[1];
			$form['md5pass'] = ''; //md5($form['pass']) . $form['challenge'];
			$form['next'] = '';
			$form['api_key'] = $this->config['api_key'];
			$form['submit'] = 'Login';
			
			$post_results = $this->post_content('https://api.facebook.com/login.php', $form);
			preg_match('`auth_token=(.*)`i', $post_results, $matches);
			
			return trim($matches[1]);
		}
		
		function Refresh(){
			$client = @new FacebookRestClient($this->config['rest_server_addr'], $this->config['api_key'], $this->config['secret'], '', false);
			$auth_token = $this->get_auth_token();
			$session_info = $client->auth_getSession($auth_token);
			$client->session_key = $session_info['session_key'];
			$uid = $session_info['uid'];
			
			$status = @$client->users_getInfo(array($uid), array('status'));
				
			if(!is_array($status))
				return;
					
			$status = $status[$uid]['status'];
			$this->cacheItem($this->name, $status['time'], $status['message'], 'http://www.facebook.com/profile.php?id=your+id+here);	
		}
	}
?>