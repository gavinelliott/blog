<?php
require_once(dirname(__FILE__) . '/lib/common.php');
$this->AddService(new RSSDataSource('wordie', 'http://wordie.org/people/feed/elliottback?wl=1472', -60*60*0, true));
?>