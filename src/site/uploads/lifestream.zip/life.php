<?php

require_once (dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-config.php');
require_once (ABSPATH . WPINC . '/rss-functions.php');
define('MAGPIE_CACHE_AGE', 1800);

$lifestream = new LifeStream();
add_action('wp_cron_hourly', 'RefreshLifeStream');

function RefreshLifeStream(){
	global $lifestream;
	$lifestream->Refresh();
}

class LifeStream {
	var $services = array();
	
	/* CONSTRUCTOR */
	function LifeStream(){
		$lifestream_dir = dirname(__FILE__) . '/data/';
		$lifestream_dir_handle = @opendir($lifestream_dir);
		
		while($lifestream_file = readdir($lifestream_dir_handle)){
			if($lifestream_file == '.' || $lifestream_file == '..' || !preg_match('`\.php$`', $lifestream_file))
				continue;
			else {
				$this->load($lifestream_dir . $lifestream_file);
			}
		}
		
		closedir($lifestream_dir_handle);
	}
	
	function load($file){
		require_once($file);
	}
	
	/* PUBLIC: */
	function AddService(&$service){
		$this->services [] = $service;
	}
	
	function Refresh(){
		foreach($this->services as $service){
			$service->Refresh();
		}
	}
	
	function Items(){
		$data = array();
		
		foreach($this->services as $service){
			$data[$service->name] = $service->Items();
		}
		
		return $data;
	}
}
?>