<?php
/**
 * Template Name: Lifestream
 **/

include_once( TEMPLATEPATH . '/life.php' );
?>
<?php get_header(); ?>

<style>
.blog th { background: #dee; color: #455; }
.blog a { background: #dee; }
.blog a:hover { background: #eee; }

.flickr th { background: #fde; color: #645; }
.flickr a { background: #fde; }
.flickr a:hover { background: #eee; }

.facebook th { background: #efe; color: #565; }
.facebook a { background: #efe; }
.facebook a:hover {	background: #eee; }

.wordie th { background: #cde; color: #345; }
.wordie a {	background: #cde; }
.wordie a:hover { background: #eee; }

.lastfm th { background: #fee;	color: #655; }
.lastfm a { background: #fee; }
.lastfm a:hover { background: #eee; }

table 
{
	border-collapse: collapse;
	margin: 0 7%;
	width: 43.0em;
}

tbody th 
{
	text-align: right;
	padding: 0.5em;
	color: #777;
}

tbody td a 
{
	display: block;
	text-decoration: none;
	padding: .5em;
	color: #333 !important;
	line-height: 1.5em !important;
}

tbody td a:hover, tbody a:visited:hover
{
	color: #333 !important;
}

</style>
	<div id="container">
		<div id="content">
			<div class="post">
			<table class="hcalendar">
			<tbody>
<?php

$details = array('title', 'link');
$list = array();

foreach($lifestream->Items() as $name => $content){
	foreach($content as $date => $item){
		$list[$date]['name'] = $name;
		$list[$date]['title'] = $item[0];
		$list[$date]['link'] = $item[1];
	}
}

krsort( $list );
$day = '';
foreach ( $list as $timestamp => $item ) {
	$this_day = date("F jS", $timestamp);
	$this_year = date("Y", $timestamp);
	if($year != $this_year){
?>	
	</tbody>
	<thead>
	<tr>
	<th colspan="3" align="right">
	<h1><?php echo $this_year; ?></h1>
	</th>
	</tr>
	</thead>
	</tbody>
<?php $year = $this_year; } ?>
<?php if( $day != $this_day) { ?>
	</tbody>
	<thead>
	<tr>
	<th colspan="3" align="left">
	<h1><?php echo $this_day; ?></h1>
	</th>
	</tr>
	</thead>
	</tbody>
<?php $day = $this_day; } ?>
<tr class="vevent <?php  echo $item["name"]; ?>" />
<td width="5%">
	<img src="<?php echo bloginfo('template_directory'). '/images/lifestream/' . $item['name'] . '.png'; ?>" alt="<?php echo $item["name"]; ?>" />
</td>
<th>
    	<abbr class="dtstart" title="<?php echo date("c",$timestamp); ?>">
    		<?php echo date("g:ia",$timestamp); ?>
    	</abbr>
</th>
<td>
    <a class="url summary" href="<?php echo $item["link"]; ?>"><?php echo $item["title"]; ?></a>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
			</div>

			<div style="clear:both;"></div>
		</div>
	</div>
<?php require_once(ABSPATH . 'wp-content/themes/manji/searchform.php'); ?>
<?php require_once(ABSPATH . 'wp-content/themes/manji/footer.php'); ?>